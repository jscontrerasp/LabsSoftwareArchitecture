export const url = process.env.COURSES_URL || 'courses-ms';
export const port = process.env.COURSES_PORT || '4001';
export const entryPoint = process.env.COURSES_ENTRY || 'courses';