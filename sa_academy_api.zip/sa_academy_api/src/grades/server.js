export const url = process.env.GRADES_URL || 'grades-ms';
export const port = process.env.GRADES_PORT || '4002';
export const entryPoint = process.env.GRADES_ENTRY || 'grades';
