export const url = process.env.STUDENTS_URL || 'students-ms';
export const port = process.env.STUDENTS_PORT || '4000';
export const entryPoint = process.env.STUDENTS_ENTRY || 'students';